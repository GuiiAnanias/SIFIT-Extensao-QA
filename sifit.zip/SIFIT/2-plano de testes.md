## 🧪 **Plano de Testes - SIFIT**

### 📌 1. **Identificação**

* **Nome do Projeto**: SIFIT - Sistema para Academias
* **Versão Avaliada**: Ambiente acadêmico disponibilizado pela UniAlfa
* **Ambiente de Testes**: [https://sifit.centrion.com.br](https://sifit.centrion.com.br)
* **Tipo de Teste**: Teste Funcional Manual
* **Data do Documento**: 08/10/2026
* **Responsável**: Guilherme Calixto

---

### 🎯 2. **Objetivo**

Verificar manualmente os principais requisitos funcionais do SIFIT, com foco nos fluxos críticos de uma academia (login, clientes, matrículas, check-in, treinos, financeiro e relatórios), nas mensagens de erro e validações e na integridade das telas disponíveis na interface web.

---

### 🧩 3. **Escopo**

**Incluído:**

* Autenticação de usuário
* Página Inicial e Dashboard
* Check-in e Presenças
* Gestão de Clientes
* Matrículas
* Avaliações Físicas
* Treinamento (Fichas, Exercícios e Turmas)
* Financeiro (Contas a Receber, Contas a Pagar, Despesas Fixas)
* Comercial (Prospecção e Planos)
* Relatórios
* Gestão (Colaboradores e Produtos)
* Saúde (Anamnese)

**Excluído:**

* Recuperação de senha, Pagar.me, Configurações, Aplicativo, abertura/fechamento de Caixa, Inteligência & Automação e SifitBox (motivos na Análise de Requisitos)
* Testes de integração com sistemas externos (WhatsApp, biometria, gateway de pagamento)
* Testes em dispositivos móveis
* Testes de performance, carga e segurança

---

### 🔧 4. **Ferramentas Utilizadas**

* Navegador Google Chrome
* Ferramentas de inspeção do navegador (DevTools)
* Jam.dev (gravação de vídeos de evidência)
* MySQL Workbench (consulta ao banco para conferência dos registros)
* GitHub + Markdown (documentação)

---

### 🧪 5. **Técnicas de Teste**

* Particionamento de equivalência
* Análise de valor limite
* Caminho feliz (Happy Path)
* Testes negativos
* Testes exploratórios

---

### 📄 6. **Critérios de Aceitação**

* Todos os casos de teste devem passar conforme o resultado esperado.
* Nenhuma falha crítica nas funcionalidades principais (login, clientes, matrículas, check-in).
* Mensagens de erro e validações devem ser claras e consistentes entre as telas.

---

### 🚦 7. **Critérios de Saída (Exit Criteria)**

* Todos os testes do escopo foram executados.
* Falhas foram registradas, analisadas e reexecutadas quando necessário.
* Evidências (prints e vídeos) de sucesso e falha estão completas.

---

### ⏱️ 8. **Cronograma Estimado**

| Atividade                   | Data Início | Data Fim   |
| --------------------------- | ----------- | ---------- |
| Planejamento de Testes      | 08/10/2026  | 08/10/2026 |
| Criação de Casos de Teste   | 08/10/2026  | 08/10/2026 |
| Execução dos Testes Manuais | xx/xx/2026  | xx/xx/2026 |
| Registro e Report de Bugs   | xx/xx/2026  | xx/xx/2026 |
| Encerramento e Evidências   | xx/xx/2026  | xx/xx/2026 |

---

### 📋 9. **Módulos a Serem Testados**

| Código RF | Módulo                                  | Prioridade |
| --------- | --------------------------------------- | ---------- |
| RF01      | Login                                   | Alta       |
| RF02      | Página Inicial e Dashboard              | Média      |
| RF03      | Check-in e Presenças                    | Alta       |
| RF04      | Gestão de Clientes                      | Alta       |
| RF05      | Matrículas                              | Alta       |
| RF06      | Avaliações Físicas                      | Média      |
| RF07      | Treinamento (Fichas, Exercícios, Turmas)| Média      |
| RF08      | Financeiro                              | Alta       |
| RF09      | Comercial (Prospecção e Planos)         | Média      |
| RF10      | Relatórios                              | Média      |
| RF11      | Gestão (Colaboradores e Produtos)       | Baixa      |
| RF12      | Saúde (Anamnese)                        | Baixa      |

---

### 🧾 10. **Massa de Dados**

* Todo registro criado nos testes usa o prefixo **"QA Guilherme"** no nome (ex.: cliente "QA Guilherme Cliente 01"), para identificar os dados de teste no ambiente compartilhado.
* As exclusões são feitas apenas em registros criados pelo próprio testador.

---

### 🐞 11. **Gestão de Defeitos**

* Bugs são documentados com:

  * Título
  * Descrição
  * Passos para reproduzir
  * Evidência (print ou vídeo no Jam.dev)
  * Severidade (Crítica, Alta, Média, Baixa) e prioridade

---

### 📌 12. **Riscos Identificados**

| Risco                                                   | Impacto | Mitigação                                                   |
| ------------------------------------------------------- | ------- | ----------------------------------------------------------- |
| Sistema fora do ar                                      | Alto    | Tentar novamente após intervalo                             |
| Ambiente compartilhado com a turma (dados alterados por outros) | Médio   | Usar o prefixo "QA Guilherme" e conferir os dados antes de cada teste |
| Base com dados pessoais de clientes                     | Médio   | Borrar CPF, telefone e e-mail de terceiros nos prints       |
| Testes limitados a um único usuário de acesso           | Médio   | Documentar o limite no escopo                               |

---

### 📁 13. **Entregáveis**

* Análise de Requisitos (.md)
* Plano de Testes (.md)
* Cenários e Casos de Teste (.md, formato BDD/Gherkin)
* Evidências de Execução (prints e vídeos por RF)
* Relatório de Bugs
* Relatório Final de Execução
