## 📦 **Requisitos Funcionais Detalhados para Testes Manuais - SIFIT**

> Levantamento feito por navegação no ambiente sifit.centrion.com.br em 08/10/2026.
> O SIFIT é um sistema web de gestão para academias. O menu lateral é organizado nos grupos:
> **Principal, Operação da Academia, Treinamento, Financeiro, Comercial, Gestão, Saúde, Inteligência e Configurações.**

---

### 🔐 **RF01 - Autenticação de Usuário**

**Descrição**: O acesso ao sistema é feito pela tela de login (`/login`).

* **Funcionalidades esperadas**:

  * Login com usuário e senha válidos, redirecionando para a Página Inicial (`/dashboard`).
  * Mensagem de erro em caso de credenciais inválidas.
  * Validação de campos obrigatórios (Login e Senha).
  * Opção "Manter conectado" para manter a sessão ativa.
  * Link "Esqueci minha senha" para recuperação de acesso.

---

### 🏠 **RF02 - Página Inicial e Dashboard**

**Descrição**: Após o login, o sistema exibe a Página Inicial com saudação ao usuário e widgets de acompanhamento. O item "Dashboard" (`/dash`) mostra indicadores da academia.

* **Funcionalidades esperadas**:

  * Página Inicial com: Inteligência de Retenção, principais motivos de risco, ações recomendadas, gráficos Por Horário e Por Dia da Semana, Mensalidades pendentes, Agenda de hoje, Últimas entradas na academia e Aniversariantes do dia.
  * Atalhos de ação: "Cobrar agora", "Enviar mensagem", "Ver avaliações", "Cobrar todos no WhatsApp".
  * Dashboard com o card "Inteligência Sifit" e os indicadores Alunos em risco, Aniversariantes, Avaliações vencendo e Frequência em queda.
  * Navegação funcional pelo menu lateral.

---

### ✅ **RF03 - Check-in e Presenças**

**Descrição**: Controle de entrada dos alunos na academia.

* **Funcionalidades esperadas**:

  * Check-in manual pelo código do cliente ("Entrada rápida" > "Realizar check-in").
  * Check-in por QR Code ("Escanear QR Code").
  * Filtros: Todos, Presentes agora, Não compareceram, Check-in pendente.
  * Busca por nome, código ou plano.
  * Tela de Presenças com busca por cliente e filtros Hoje, Esta semana e Este mês.

---

### 👤 **RF04 - Gestão de Clientes**

**Descrição**: Cadastro e manutenção dos alunos da academia.

* **Funcionalidades esperadas**:

  * Listagem paginada com colunas Código, Nome, Plano, Status e Biometria / Visitado.
  * Filtros por código, nome e campos de seleção.
  * Botão "Novo Cliente" (`/adicionar-cliente`) com os campos obrigatórios **Nome, Status, Sexo e Data de Nascimento**.
  * Campos opcionais: dados pessoais (CPF, RG, tipo sanguíneo, foto), contato (telefone, WhatsApp, contato de emergência, e-mail), endereço (CEP, país, estado, cidade etc.), acesso (código do leitor, sempre liberado, usuário e senha do app) e observações.
  * Ações "Visualizar" e "Deletar" em cada cliente.

---

### 📝 **RF05 - Matrículas**

**Descrição**: Vínculo de um cliente a um plano/modalidade, com condições de pagamento.

* **Funcionalidades esperadas**:

  * Listagem com Código, Nome, Plano e Status, filtros por código, nome e data.
  * "Cadastrar Matrícula" (`/adicionar-matricula`) com: busca do cliente, data, status, renovada, moeda, modalidade, data inicial e final, pagamento via sistema, tipo de pagamento, taxa de matrícula, dia de vencimento, valor da parcela, desconto, valor total e observação.
  * Ações "Visualizar", "Cancelar" e "Deletar".

---

### 📏 **RF06 - Avaliações Físicas**

**Descrição**: Registro e acompanhamento das avaliações físicas dos alunos.

* **Funcionalidades esperadas**:

  * Listagem com Código, Nome, Data / Hora, Personal, Status e Ações.
  * "Cadastrar Avaliação", "Fazer Avaliação", "Alterar", "Visualizar" e "Deletar".
  * Envio por "Link" e "Comparação" entre avaliações do mesmo aluno.

---

### 🏋️ **RF07 - Treinamento (Fichas, Exercícios e Turmas)**

**Descrição**: Montagem de treinos e organização de turmas.

* **Funcionalidades esperadas**:

  * Fichas de Treino: listagem com Código, Aluno, Data Inicial, Data Final, Status; filtro por status (Ativo, Inativo, Cancelado, Finalizado); "Cadastrar Ficha" e "Limpar filtros".
  * Exercícios: biblioteca agrupada por grupo muscular, com "Adicionar", "Visualizar" e "Deletar".
  * Turmas: listagem com Nome, Plano, Horário, Dias e Status; "Cadastrar Turma", "Editar" e "Deletar".
  * Cadastros de apoio: Grupos Musculares, Objetivos de Treino, Grupos, Categorias Crossfit e Box - Turmas.

---

### 💰 **RF08 - Financeiro**

**Descrição**: Controle de recebimentos, pagamentos, caixa e despesas.

* **Funcionalidades esperadas**:

  * Contas a Receber: "Nova Conta", filtro por código, cliente, data de Vencimento/Recebimento, período (Hoje, Ontem, Últimos 7 dias, Este mês) e status (Pendente, Recebido, Vencido, Cancelado).
  * Contas a Pagar: "Nova Conta", filtro por fornecedor/colaborador, data de Vencimento/Pagamento e status (Pendente, Pago, Vencido, Cancelado).
  * Caixas: "Abrir Caixa", "Visualizar", "Imprimir", filtro por status (Aberto, Fechado).
  * Despesas Fixas: "Nova Despesa" com valor e recorrência (1 dia a 1 ano), filtro por status.

---

### 📈 **RF09 - Comercial (Prospecção e Planos)**

**Descrição**: Funil de vendas e oferta de planos.

* **Funcionalidades esperadas**:

  * Prospecção: "Adicionar Lead", busca por nome, e-mail, telefone ou código, filtro por estágio (Novo Contato, Interessado, Fez Aula Experimental, Proposta, Fechado).
  * Planos: "Novo Plano", listagem com Nome, Alunos, Valor, Duração e Status, ranking "Planos com mais alunos".
  * Cadastros de apoio: Modelos de Contrato, Tipos de Pagamento e Bandeiras.

---

### 📊 **RF10 - Relatórios**

**Descrição**: Geração de relatórios por tipo e período.

* **Funcionalidades esperadas**:

  * Tipos disponíveis: Avaliações, Clientes, Colaboradores, Matrículas, Contas a Receber, Contas a Pagar e Caixas.
  * Seleção de data inicial e final.
  * Botão "Gerar Relatório".

---

### 🧑‍💼 **RF11 - Gestão (Colaboradores e Produtos)**

**Descrição**: Cadastros internos da academia.

* **Funcionalidades esperadas**:

  * Colaboradores: "Novo Colaborador", busca por código e nome, acesso a "Funções", "Visualizar" e "Deletar".
  * Produtos: "Novo", filtro por status e tipo (Venda ou Pontuação), colunas Valor / Pontos.
  * Cadastros de apoio: Fornecedores, Tipos de Documentos, Atividades, Pontuação e Enquetes.

---

### 🩺 **RF12 - Saúde (Anamnese)**

**Descrição**: Questionários de saúde dos alunos.

* **Funcionalidades esperadas**:

  * Fichas de Anamnese: "Nova Anamnese", busca por cliente e filtro por status (Concluído, Pendente).
  * Cadastros de apoio: Modelos, Categorias e Perguntas de anamnese.

---

### 🚫 **Fora do escopo deste ciclo**

| Módulo | Motivo |
| ------ | ------ |
| Esqueci minha senha | Dispararia e-mail de recuperação para o dono real da conta de teste |
| Pagar.me | Integração de pagamento real |
| Configurações / Aplicativo | Alterações afetam o ambiente de toda a turma |
| Caixas (abrir/fechar) | Movimento de caixa é compartilhado entre os usuários do ambiente |
| Inteligência & Automação, SifitBox | Módulos complementares, ficam para um próximo ciclo |
