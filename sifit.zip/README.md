🧪 **Testes-Manuais**

Repositório dedicado ao estudo, prática e documentação de testes manuais de software, com foco em:

* Aprendizado de QA
* Organização de casos de teste
* Melhoria contínua na análise e cobertura de testes

🎯 **Objetivo**

Este projeto foi criado com o objetivo de:

* Consolidar conhecimentos de testes manuais
* Simular testes em sistemas reais
* Criar um portfólio técnico bem estruturado para futuras oportunidades profissionais

Trabalho da disciplina **Extensão - Qualidade de Software** do curso de Sistemas para Internet da UniAlfa.

🧱 **Estrutura do repositório**

A estrutura está organizada por pastas, cada uma representando um sistema testado:

📁 **SIFIT** ↳ Análise de Requisitos, Plano de Testes, Cenários e Casos de Teste, Relatório de Bugs, Relatório Final e Evidências

```
SIFIT/
├── 1-Analise de requisitos.md
├── 2-plano de testes.md
├── 3-Relatorio-de-Bugs.md
├── 4- Relatorio dos testes.md
└── Cenarios de testes/   (12 cenários, 36 casos de teste)
```

🧪 **Metodologia**

* **Técnicas aplicadas:** Testes Positivos, Negativos, Exploratório, Funcional, Valor Limite
* **Ferramentas:** Markdown, GitHub, Jam.dev, MySQL Workbench
* **Formatos:** BDD (Gherkin), Tabelas e Checklist
* **Processos:** Planejamento de Teste, Execução e Relatório

📌 **Status do Projeto**

✅ Ativo e em constante evolução
📋 Feedbacks são bem-vindos!

👤 **Autor**

Guilherme Calixto
